package J06007;

public class MonHoc {
    private String id, name;

    public MonHoc(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
